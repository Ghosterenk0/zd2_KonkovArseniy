﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zd2_KonkovArseniy
{
    class Contact
    {
        public string Name { get; set; } // приватное поле
        public string Phone { get; set; } // приватное поле

        public Contact(string name, string phone) // Конструктор класса Contact
        {
            this.Name = name;
            this.Phone = phone;
        }
    }
}
