﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace zd2_KonkovArseniy
{
    public partial class Form1 : Form
    {
        PhoneBook phonebook = new PhoneBook(); // Экземпляр класса PhoneBook
        string path = "";
        public Form1() 
        {
            InitializeComponent();
            dataGridView1.ContextMenuStrip = contextMenuStrip1;

            dataGridView1.Columns.Add("name", "Имя");
            dataGridView1.Columns.Add("phone", "Телефон");
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void добавитьToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e) // Кнопка ContextMenuStrip -> Закрытие формы
        {
            Application.Exit();
        }

        private void записатьВФайлToolStripMenuItem_Click(object sender, EventArgs e) // Кнопка для записи файла на носитель
        {
            if (phonebook.GetPhoneBook().Count > 0)
            {
                SaveFileDialog sf = new SaveFileDialog();
                sf.Filter = "|*.csv";
                sf.FileName = "Телефоная книга.csv";
                if (sf.ShowDialog() == DialogResult.OK)
                {

                    string path = sf.FileName;
                    PhoneBookLoader.Save(phonebook, path);
                    using (StreamWriter sw = File.AppendText(path))
                        phonebook.GetPhoneBook().ForEach(c => sw.WriteLine($"{c.Name};{c.Phone}"));
                }
            }
            else
            {
                MessageBox.Show("Телефоная книга пуста");
            }
        }

        private void книгуToolStripMenuItem_Click(object sender, EventArgs e) // Кнопка открытия файла и чтение из файла информацию в datagridview
        {
            OpenFileDialog of = new OpenFileDialog();
            of.Filter = "|*.csv";
            if(of.ShowDialog() == DialogResult.OK)
            {
                path = of.FileName;
                PhoneBookLoader.Load(phonebook, path);

                phonebook.GetPhoneBook().ForEach(c => dataGridView1.Rows.Add(c.Name, c.Phone));
                
            }
        }

        private void контактToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void toolStripTextBox1_Click(object sender, EventArgs e)
        {

        }

        private void удалитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e) // Кнопка вызова ToolStrip
        {
            if (dataGridView1.Rows.Count > 1)
            {
                toolStrip2.Visible = true;
            }
            else
            {
                MessageBox.Show("Список пуст");
            }
        }

        private void контактToolStripMenuItem_Click_1(object sender, EventArgs e) // Кнопка вызова ToolStrip
        {
            toolStrip1.Visible = true;
        }

        private void toolStripButton1_Click(object sender, EventArgs e) // Кнопка для добавления контакта в 
        {
            if (TstbName.Text != "" && TsTbPhone.Text != "")
            {
                for (int i = 0; i < TstbName.Text.Length; i++)
                {
                    if (char.IsDigit(TstbName.Text[i]))
                    {
                        MessageBox.Show("Имя не может содержать цифр");
                        break;
                    }
                    else
                    {
                        for (int j = 0; j < TsTbPhone.TextLength; j++)
                        {
                            if (char.IsLetter(TsTbPhone.Text[i]) && (TsTbPhone.Text[0] != '+' && TsTbPhone.Text[1] != '7' || TsTbPhone.Text[0] != '8') && (TsTbPhone.TextLength != 11 || TsTbPhone.TextLength != 12))
                            {
                                MessageBox.Show("Не корректно введен номер телефона");
                                break;
                            }
                            else
                            {
                                Contact contact = new Contact(TstbName.Text, TsTbPhone.Text);
                                phonebook.AddContact(contact);
                                dataGridView1.Rows.Add(contact.Name, contact.Phone);
                                break;
                            }
                        }
                        break;
                    }
                }
                TstbName.Text = "";
                TsTbPhone.Text = "";
            }
            else
            {
                MessageBox.Show("Заполните пустые поля");
            }
        }

        private void TstbName_Click(object sender, EventArgs e) // Обработчик события - при нажатии на textbox замена на пустую строку
        {
            TstbName.Text = "";
        }

        private void TsTbPhone_Click(object sender, EventArgs e) // Обработчик события - при нажатии на textbox замена на пустую строку
        {
            TsTbPhone.Text = "";
        }

        private void tstbSearchName_Click(object sender, EventArgs e) // Обработчик события - при нажатии на textbox замена на пустую строку
        {
            tstbSearchName.Text = "";
        }

        private void toolStripButton2_Click(object sender, EventArgs e) // Кнопка ContextMenuStrip для поиска имя и номера по имени
        {
            if (TstbName.Text != "")
            {
                int count = 0;
                foreach (var c in phonebook.GetPhoneBook())
                {
                    if (phonebook.SearchContact(tstbSearchName.Text.ToLower()) != null)
                    {
                        count++;
                        Contact contact = phonebook.SearchContact(tstbSearchName.Text.ToLower());
                        dataGridView1.Rows.Clear();
                        dataGridView1.Rows.Add(contact.Name, contact.Phone);

                    }
                }
                tstbSearchName.Text = "";
                MessageBox.Show($"Найдено записей {count}");
                toolStrip2.Visible = false;
                Hide_btn.Visible = true;
            }
            else
            {
                MessageBox.Show("Заполните пустые поля");
                tstbSearchName.Text = "Введите имя";
            }
            
        }

        private void toolStripButton3_Click(object sender, EventArgs e) // Кнопка закрыть ToolStrip
        {
            toolStrip1.Visible = false;
        }

        private void toolStripButton4_Click(object sender, EventArgs e) // Кнопка закрыть ToolStrip
        {
            toolStrip2.Visible = false;
            Hide_btn.Visible = false;
        }

        private void Hide_btn_Click(object sender, EventArgs e) // Кнопка скрытия поисковых результатов
        {
            dataGridView1.Rows.Clear();
            phonebook.GetPhoneBook().ForEach(c => dataGridView1.Rows.Add(c.Name, c.Phone));
        }

        private void контактToolStripMenuItem1_Click(object sender, EventArgs e) //Кнопка для удаления выделенных контактов в DataGridView
        {
            try {
                if (dataGridView1.SelectedRows.Count > 0)
                {

                    foreach (DataGridViewRow c in dataGridView1.SelectedRows)
                    {
                        dataGridView1.Rows.RemoveAt(c.Index);
                    }

                }
                else
                {
                    MessageBox.Show("Строка для удаления не выбрана");
                }
            }
            catch
            {
                MessageBox.Show("Ошибка");
            }
        }

        private void очиститьToolStripMenuItem_Click(object sender, EventArgs e) // Кнопка для очистки DataGridView и записей в list
        {
            dataGridView1.Rows.Clear();
            if(phonebook.ClearBook() != "" )
            {
                MessageBox.Show(phonebook.ClearBook());
            }
            else
            {
                phonebook.ClearBook();
            }
        }
    }
}
