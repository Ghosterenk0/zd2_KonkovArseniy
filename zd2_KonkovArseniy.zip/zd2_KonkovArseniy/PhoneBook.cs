﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zd2_KonkovArseniy
{
    class PhoneBook
    {

        List<Contact> phonebook = new List<Contact>(); // Список из обьектов Contact

        
        public Contact SearchContact(string name) // Метод для поиска контакта по имени
        {
            foreach (var p in phonebook)
            {
                if (p.Name.ToLower().Contains(name))
                {
                    return p;
                }
                else
                {
                    return null;
                }
            }
            return null;
        }

        public void AddContact(Contact contact) // Метод добавления контакта в список
        {
            phonebook.Add(contact);
        }
        public string DeleteContact(Contact contact) // Метод удаления контакта из списка
        {
            if(phonebook.Count > 0 && phonebook.Contains(contact))
            {
                phonebook.Remove(contact);
            }
            else
            {
                return "Контакт не найден";
            }
            return "";
        }

        public List<Contact> GetPhoneBook() // Метод возращающий список из обьектов Contact
        {
            return phonebook;
        }

        public string ClearBook() // Метод очищающий список
        {
            if (phonebook.Count > 0)
            {
                phonebook.Clear();
            }
            else
            {
                return "Список пуст";
            }
            return "";
        }


    }
}
