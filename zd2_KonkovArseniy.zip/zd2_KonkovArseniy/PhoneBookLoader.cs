﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace zd2_KonkovArseniy
{
    static class PhoneBookLoader
    {
        public static void Load(PhoneBook phoneBook, string fileName) // Метод для загрузки записей о телефонах в файл
        {
            if (File.Exists(fileName))
            {
                using (StreamReader sr = new StreamReader(fileName))
                {
                    while (!sr.EndOfStream)
                    {
                        string[] NameAndPhone = sr.ReadLine().Split(';');
                        Contact contact = new Contact(NameAndPhone[0], NameAndPhone[1]);
                        phoneBook.AddContact(contact);
                    }
                }
            }
        }
        public static void Save(PhoneBook phoneBook, string fileName) // Метод для сохранения записей в файл
        {
            using (StreamWriter sw = new StreamWriter(fileName))
            {
                foreach (var c in phoneBook.GetPhoneBook())
                {
                    sw.WriteLine($"{c.Name};{c.Phone}");
                }
                
            }
            
        }
    }
}
